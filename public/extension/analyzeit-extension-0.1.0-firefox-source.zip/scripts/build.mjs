// node scripts/build.mjs [--target chromium|firefox|safari] [--dev]  ->  dist/<target>[-dev]
// All code in src/ is shared. Only this manifest differs per browser. --dev adds localhost bridge origins and a stub platform for tests.
import { cpSync, mkdirSync, rmSync, writeFileSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { deflateSync } from 'node:zlib';
import { buildSync } from 'esbuild';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const dev = process.argv.includes('--dev');
const ti = process.argv.indexOf('--target');
const target = ti > 0 ? process.argv[ti + 1] : 'chromium';
if (!['chromium', 'firefox', 'safari'].includes(target)) throw new Error('unknown target ' + target);
const out = join(root, 'dist', target + (dev ? '-dev' : ''));
const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'));

const appOrigins = ['https://analyzeit.in', 'https://www.analyzeit.in'];
if (dev) appOrigins.push('http://localhost:3000', 'http://localhost:3100', 'http://127.0.0.1:4010');
const stubX = process.argv.includes('--stub-x'); // UI testing: make "x" point at the local stub page so the real app can be driven end to end
const stub = {
  ...(stubX ? { x: { label: 'X', origin: 'http://127.0.0.1:4011', compose: 'http://127.0.0.1:4011/compose', limit: 280, editor: ['#box'], postButton: ['#post'] } } : {}),
  stub: { label: 'Stub', origin: 'http://127.0.0.1:4011', compose: 'http://127.0.0.1:4011/compose', limit: 280, editor: ['#box'], postButton: ['#post'] },
};

rmSync(out, { recursive: true, force: true });
mkdirSync(out, { recursive: true });
cpSync(join(root, 'src'), out, { recursive: true });
writeFileSync(join(out, 'config.js'),
  `export const EXTRA_PLATFORMS = ${dev ? JSON.stringify(stub) : '{}'};\nexport const APP_ORIGINS = ${JSON.stringify(appOrigins)};\nexport const DEV = ${dev};\n`);

// The in-page runner imports policy.js, but content scripts are injected as classic files, so bundle it.
buildSync({ entryPoints: [join(out, 'runner.js')], bundle: true, format: 'iife', outfile: join(out, 'runner.js'), allowOverwrite: true, logLevel: 'error' });
// Safari cannot load a module background script, so bundle it (with core.js and config.js) into one classic script.
if (target === 'safari') buildSync({ entryPoints: [join(out, 'background.js')], bundle: true, format: 'iife', outfile: join(out, 'background.js'), allowOverwrite: true, logLevel: 'error' });

// A plain rounded-square icon, written as PNG without any image dependency.
function icon(size) {
  const raw = Buffer.alloc((size * 4 + 1) * size);
  for (let y = 0; y < size; y++) {
    raw[y * (size * 4 + 1)] = 0;
    for (let x = 0; x < size; x++) {
      const o = y * (size * 4 + 1) + 1 + x * 4;
      const r = size * 0.22, dx = Math.max(r - x, x - (size - 1 - r), 0), dy = Math.max(r - y, y - (size - 1 - r), 0);
      const inside = dx * dx + dy * dy <= r * r;
      raw.set(inside ? [0x1f, 0x2a, 0x44, 255] : [0, 0, 0, 0], o);
    }
  }
  const crc = (buf) => { let c, t = []; for (let n = 0; n < 256; n++) { c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } let v = 0xffffffff; for (const b of buf) v = t[(v ^ b) & 255] ^ (v >>> 8); return (v ^ 0xffffffff) >>> 0; };
  const chunk = (type, data) => { const len = Buffer.alloc(4); len.writeUInt32BE(data.length); const td = Buffer.concat([Buffer.from(type), data]); const c = Buffer.alloc(4); c.writeUInt32BE(crc(td)); return Buffer.concat([len, td, c]); };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(size, 0); ihdr.writeUInt32BE(size, 4); ihdr[8] = 8; ihdr[9] = 6;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}
const icons = {};
for (const n of [16, 32, 48, 128]) { writeFileSync(join(out, `icon-${n}.png`), icon(n)); icons[n] = `icon-${n}.png`; }

// The four posting sites, plus "any https site" which the person can only grant one site at a time (browser prompt).
const optional = ['https://x.com/*', 'https://bsky.app/*', 'https://www.threads.net/*', 'https://www.linkedin.com/*', 'https://*/*'];

const manifest = {
  manifest_version: 3,
  name: dev ? 'AnalyzeIt (dev)' : 'AnalyzeIt',
  version: pkg.version,
  description: 'Posts or fills drafts you approved in AnalyzeIt, only after you confirm here, only on sites you allow.',
  ...(target === 'chromium' ? { minimum_chrome_version: '110', background: { service_worker: 'background.js', type: 'module' } } : {}),
  // Firefox and Safari run MV3 background code as an event page (scripts), not a service worker.
  ...(target === 'firefox' ? { background: { scripts: ['background.js'], type: 'module' } } : {}),
  ...(target === 'safari' ? { background: { scripts: ['background.js'] } } : {}),
  icons,
  ...(target === 'firefox' ? { browser_specific_settings: { gecko: { id: 'extension@analyzeit.in', strict_min_version: '140.0', data_collection_permissions: { required: ['none'] } }, gecko_android: { strict_min_version: '142.0' } } } : {}),
  ...(target === 'safari' ? { browser_specific_settings: { safari: { strict_min_version: '17.0' } } } : {}),
  action: { default_popup: 'popup.html', default_title: 'AnalyzeIt', default_icon: icons },
  permissions: ['storage', 'scripting', 'tabs'], // tabs: read a tab's URL before injecting; scripting only works on sites the person allowed
  host_permissions: dev ? ['http://127.0.0.1:4011/*'] : [], // dev only: lets the stub platform work without the browser permission prompt
  optional_host_permissions: optional,
  content_scripts: [{ matches: appOrigins.map((o) => o + '/*'), js: ['app-bridge.js'], run_at: 'document_idle' }],
};
writeFileSync(join(out, 'manifest.json'), JSON.stringify(manifest, null, 2));
console.log('built', out);
