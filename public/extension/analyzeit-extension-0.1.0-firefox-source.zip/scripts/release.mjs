// node scripts/release.mjs [--site DIR]
// Produces versioned, store-ready packages in dist/release/ plus SHA256SUMS. Publishes nothing.
//   analyzeit-extension-<v>-chromium.zip   Chrome Web Store and Edge Add-ons (one package for both)
//   analyzeit-extension-<v>-firefox.zip    addons.mozilla.org (listed) or signing as unlisted
//   analyzeit-extension-<v>-firefox-source.zip   readable source Mozilla asks for because runner.js is bundled
//   analyzeit-extension-<v>-safari-project.zip   Xcode project (Safari Web Extension app wrapper), unsigned
// --site DIR also copies the packages and SHA256SUMS to DIR (the website's /extension downloads).
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { cpSync, existsSync, mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'));
const v = pkg.version;
const out = join(root, 'dist', 'release');
const sh = (cmd, args, cwd = root) => execFileSync(cmd, args, { cwd, stdio: 'pipe' });

rmSync(out, { recursive: true, force: true });
mkdirSync(out, { recursive: true });

// zip with stable ordering and timestamps so the same source gives the same bytes
function zipDir(dir, file) {
  sh('sh', ['-c', `find . -type f ! -name .DS_Store | LC_ALL=C sort | zip -X -q "${file}" -@`], dir);
}

for (const target of ['chromium', 'firefox', 'safari']) sh('node', ['scripts/build.mjs', '--target', target]);
for (const t of ['chromium', 'firefox']) {
  const m = JSON.parse(readFileSync(join(root, 'dist', t, 'manifest.json'), 'utf8'));
  if (m.version !== v) throw new Error(`${t} manifest version ${m.version} != package version ${v}`);
  if (/dev/i.test(m.name) || JSON.stringify(m).includes('127.0.0.1') || JSON.stringify(m).includes('localhost')) throw new Error(`${t} build looks like a dev build`);
}
zipDir(join(root, 'dist', 'chromium'), join(out, `analyzeit-extension-${v}-chromium.zip`));
zipDir(join(root, 'dist', 'firefox'), join(out, `analyzeit-extension-${v}-firefox.zip`));

// Firefox source package: what a reviewer needs to rebuild runner.js byte for byte.
const src = join(root, 'dist', '_source');
rmSync(src, { recursive: true, force: true });
mkdirSync(src, { recursive: true });
for (const p of ['src', 'scripts', 'package.json', 'package-lock.json', 'store/BUILD.md']) if (existsSync(join(root, p))) cpSync(join(root, p), join(src, p), { recursive: true });
zipDir(src, join(out, `analyzeit-extension-${v}-firefox-source.zip`));
rmSync(src, { recursive: true, force: true });

// Safari: generate the Xcode project, then zip it without build products.
sh('sh', ['scripts/safari.sh']);
// (safari/AnalyzeIt only: safari/build holds compiled output that does not belong in the package)
zipDir(join(root, 'safari', 'AnalyzeIt'), join(out, `analyzeit-extension-${v}-safari-project.zip`));

const files = readdirSync(out).filter((f) => f.endsWith('.zip')).sort();
const sums = files.map((f) => `${createHash('sha256').update(readFileSync(join(out, f))).digest('hex')}  ${f}`).join('\n') + '\n';
writeFileSync(join(out, 'SHA256SUMS'), sums);

const si = process.argv.indexOf('--site');
if (si > 0) {
  const dest = process.argv[si + 1];
  mkdirSync(dest, { recursive: true });
  for (const f of [...files, 'SHA256SUMS']) cpSync(join(out, f), join(dest, f));
  console.log('copied to', dest);
}
console.log(sums);
