#!/bin/sh
# Builds the Safari Web Extension app wrapper locally (unsigned, not published). Needs Xcode.
#   scripts/safari.sh          generate safari/AnalyzeIt.xcodeproj from dist/safari and compile it
# To use it in Safari: open the project in Xcode, set your development team, run, then enable the extension in
# Safari > Settings > Extensions (and "Allow unsigned extensions" under Develop for an unsigned local build).
set -eu
cd "$(dirname "$0")/.."
node scripts/build.mjs --target safari
rm -rf safari
mkdir safari
xcrun safari-web-extension-converter dist/safari --project-location safari --app-name AnalyzeIt \
  --bundle-identifier in.analyzeit.AnalyzeIt --macos-only --no-open --no-prompt --force
xcodebuild -project safari/AnalyzeIt/AnalyzeIt.xcodeproj -scheme AnalyzeIt -configuration Debug \
  -derivedDataPath safari/build CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build | tail -5
