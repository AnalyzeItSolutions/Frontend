// Runs on AnalyzeIt's own pages only. Lets the page see that the extension is installed and hand it an approved draft.
// The page never gets platform access, settings write access or anything stored in the extension.
(() => {
  const here = location.origin;
  const post = (msg) => window.postMessage({ source: 'analyzeit-extension', ...msg }, here);

  chrome.runtime.sendMessage({ type: 'hello' }).then((r) => r && post({ type: 'hello', version: r.version, platforms: r.platforms, paused: r.paused })).catch(() => {});

  window.addEventListener('message', async (ev) => {
    if (ev.source !== window || ev.origin !== here) return;
    const d = ev.data;
    if (!d || d.source !== 'analyzeit-app') return;
    if (d.type === 'ping') {
      const r = await chrome.runtime.sendMessage({ type: 'status' }).catch(() => null);
      if (r) post({ type: 'hello', version: r.version, platforms: r.platforms, paused: r.paused });
    } else if (d.type === 'plan') {
      const r = await chrome.runtime.sendMessage({ type: 'plan', plan: d.plan, sha256: d.sha256 }).catch((e) => ({ ok: false, reason: String(e) }));
      post({ type: 'plan-accepted', planId: d.plan?.id, ...r });
    } else if (d.type === 'fill') {
      const r = await chrome.runtime.sendMessage({ type: 'fill', job: { draftId: d.draftId, platform: d.platform, text: d.text, sha256: d.sha256 } }).catch((e) => ({ ok: false, reason: String(e) }));
      post({ type: 'accepted', draftId: d.draftId, ...r });
    }
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.source === 'analyzeit-extension') post(msg);
  });
})();
