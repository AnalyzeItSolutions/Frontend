import { PLATFORMS, checkJob, blockedReason, withCount, capFor, usedToday } from './core.js';
import { APP_ORIGINS } from './config.js';
import { receivePlan, confirmView, confirmAnswer } from './plans.js';

const VERSION = chrome.runtime.getManifest().version;

async function settings() {
  return (await chrome.storage.local.get('settings')).settings || {};
}
async function saveSettings(s) {
  await chrome.storage.local.set({ settings: s });
}
async function pending() {
  return (await chrome.storage.session.get('pending')).pending || {};
}
async function setPending(p) {
  await chrome.storage.session.set({ pending: p });
}

async function hasAccess(platform) {
  return chrome.permissions.contains({ origins: [PLATFORMS[platform].origin + '/*'] });
}

function tellApp(tabId, msg) {
  chrome.tabs.sendMessage(tabId, { source: 'analyzeit-extension', ...msg }).catch(() => {});
}

async function status() {
  const s = await settings();
  const platforms = {};
  for (const [k, p] of Object.entries(PLATFORMS)) {
    platforms[k] = { label: p.label, allowed: await hasAccess(k), cap: capFor(s, k), used: usedToday(s, k), paused: !!s.paused?.[k] };
  }
  return { version: VERSION, paused: !!s.paused?.all, platforms };
}

async function startFill(job, appTabId) {
  const bad = await checkJob(job);
  if (bad) return { ok: false, reason: bad };
  const s = await settings();
  const blocked = blockedReason(s, job.platform);
  if (blocked) return { ok: false, reason: blocked };
  if (!(await hasAccess(job.platform))) {
    return { ok: false, reason: `Allow ${PLATFORMS[job.platform].label} in the AnalyzeIt extension (toolbar icon) first.`, needsPermission: job.platform };
  }
  const tab = await chrome.tabs.create({ url: PLATFORMS[job.platform].compose, active: true });
  const p = await pending();
  p[tab.id] = { job: { draftId: job.draftId, platform: job.platform, text: job.text, sha256: job.sha256 }, appTabId };
  await setPending(p);
  return { ok: true, state: 'opened' };
}

chrome.tabs.onUpdated.addListener(async (tabId, info) => {
  if (info.status !== 'complete') return;
  const p = await pending();
  const entry = p[tabId];
  if (!entry || entry.injected) return;
  const platform = PLATFORMS[entry.job.platform];
  const tab = await chrome.tabs.get(tabId);
  // Never inject anywhere but the platform's own origin (a redirect to a login or other site gets nothing).
  if (!tab.url || new URL(tab.url).origin !== new URL(platform.origin).origin) return;
  entry.injected = true;
  await setPending(p);
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['filler.js'] });
    await chrome.tabs.sendMessage(tabId, { type: 'job', text: entry.job.text, sha256: entry.job.sha256, label: platform.label, selectors: platform.editor });
  } catch (e) {
    tellApp(entry.appTabId, { type: 'result', draftId: entry.job.draftId, ok: false, reason: 'Could not reach the page: ' + e.message });
  }
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  const p = await pending();
  const entry = p[tabId];
  if (!entry) return;
  delete p[tabId];
  await setPending(p);
  if (!entry.done) tellApp(entry.appTabId, { type: 'result', draftId: entry.job.draftId, ok: false, reason: 'The tab was closed before the text was filled.' });
});

chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  (async () => {
    // From the app's bridge script
    if (msg?.type === 'hello') return respond({ ok: true, ...(await status()) });
    if (msg?.type === 'status') return respond({ ok: true, ...(await status()) });
    if (msg?.type === 'fill') {
      if (!sender.tab || !sender.url || !APP_ORIGINS.includes(new URL(sender.url).origin)) return respond({ ok: false, reason: 'Not from AnalyzeIt.' });
      return respond(await startFill(msg.job, sender.tab.id));
    }
    if (msg?.type === 'plan') return respond(await receivePlan(msg, sender));
    if (msg?.type === 'confirm-view') return respond(await confirmView(msg, sender));
    if (msg?.type === 'confirm-answer') return respond(await confirmAnswer(msg, sender));
    // From a platform page we injected into
    if (msg?.type === 'filled' && sender.tab) {
      const p = await pending();
      const entry = p[sender.tab.id];
      if (!entry) return respond({ ok: false });
      if (msg.sha256 !== entry.job.sha256) return respond({ ok: false });
      entry.done = true;
      await setPending(p);
      await saveSettings(withCount(await settings(), entry.job.platform));
      tellApp(entry.appTabId, { type: 'result', draftId: entry.job.draftId, ok: true, state: 'filled' });
      return respond({ ok: true });
    }
    if (msg?.type === 'declined' && sender.tab) {
      const p = await pending();
      const entry = p[sender.tab.id];
      if (entry) {
        entry.done = true;
        await setPending(p);
        tellApp(entry.appTabId, { type: 'result', draftId: entry.job.draftId, ok: false, reason: msg.reason || 'Cancelled on the page.' });
      }
      return respond({ ok: true });
    }
    // From the popup
    if (msg?.type === 'set') {
      const s = await settings();
      if (msg.paused !== undefined) s.paused = { ...(s.paused || {}), [msg.platform || 'all']: !!msg.paused };
      if (msg.cap !== undefined && msg.platform) s.caps = { ...(s.caps || {}), [msg.platform]: Number(msg.cap) };
      await saveSettings(s);
      return respond({ ok: true, ...(await status()) });
    }
    respond({ ok: false });
  })();
  return true;
});

chrome.runtime.onInstalled.addListener(async () => {
  // Tell any open AnalyzeIt tab right away so the app flips to Connected without a reload.
  const tabs = await chrome.tabs.query({ url: APP_ORIGINS.map((o) => o + '/*') });
  for (const t of tabs) tellApp(t.id, { type: 'hello', ...(await status()) });
});
