// Overwritten by scripts/build.mjs. Production has no extra platforms.
export const EXTRA_PLATFORMS = {};
export const APP_ORIGINS = ['https://analyzeit.in', 'https://www.analyzeit.in'];
export const DEV = false;
