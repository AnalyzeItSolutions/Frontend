// The extension's own confirmation window. Websites cannot reach or click anything here.
import { describeStep } from './policy.js';

const id = new URL(location.href).searchParams.get('id');
const $ = (s) => document.getElementById(s);

const view = await chrome.runtime.sendMessage({ type: 'confirm-view', id });
if (!view?.ok) {
  $('title').textContent = 'This request is no longer valid.';
  $('go').hidden = true;
} else {
  const { plan } = view;
  $('title').textContent = plan.title || 'Run this plan?';
  $('src').textContent = `Requested from AnalyzeIt · ${plan.steps.length} step${plan.steps.length === 1 ? '' : 's'}`;
  for (const s of plan.steps) {
    const li = document.createElement('li');
    li.textContent = describeStep(s);
    $('steps').append(li);
  }
  const post = plan.steps.find((s) => s.type === 'post');
  if (post) {
    $('post').hidden = false;
    $('text').textContent = post.text;
    $('commit').hidden = !post.commit;
  }
  if (post?.commit) $('go').textContent = 'Run and press Post';
  $('go').addEventListener('click', async (e) => {
    if (!e.isTrusted) return;
    $('go').disabled = true;
    await chrome.runtime.sendMessage({ type: 'confirm-answer', id, run: true });
    window.close();
  });
}
$('no').addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'confirm-answer', id, run: false });
  window.close();
});
