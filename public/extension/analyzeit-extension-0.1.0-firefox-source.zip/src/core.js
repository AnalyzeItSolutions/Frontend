// Pure logic shared by the service worker and the tests. No chrome.* calls in here.
import { EXTRA_PLATFORMS } from './config.js';

export const PLATFORMS = {
  x: {
    label: 'X',
    origin: 'https://x.com',
    compose: 'https://x.com/compose/post',
    limit: 280,
    editor: ['[data-testid="tweetTextarea_0"]', 'div[role="textbox"][contenteditable="true"]'],
    postButton: ['[data-testid="tweetButton"]'],
  },
  bluesky: {
    label: 'Bluesky',
    origin: 'https://bsky.app',
    compose: 'https://bsky.app/intent/compose',
    limit: 300,
    editor: ['div[contenteditable="true"][role="textbox"]', 'div.ProseMirror[contenteditable="true"]'],
    postButton: ['button[aria-label="Publish post"]', 'button[aria-label="Post"]'],
  },
  threads: {
    label: 'Threads',
    origin: 'https://www.threads.net',
    compose: 'https://www.threads.net/intent/post',
    limit: 500,
    editor: ['div[contenteditable="true"][role="textbox"]'],
    postButton: ['div[role="button"][aria-label="Post"]'],
  },
  linkedin: {
    label: 'LinkedIn',
    origin: 'https://www.linkedin.com',
    compose: 'https://www.linkedin.com/feed/?shareActive=true',
    limit: 3000,
    editor: ['.ql-editor[contenteditable="true"]', 'div[role="textbox"][contenteditable="true"]'],
    postButton: ['button.share-actions__primary-action'],
  },
  ...EXTRA_PLATFORMS,
};

export const DEFAULT_CAP = 5;
export const MAX_CAP = 20;

export async function sha256Hex(text) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

/** Is this job something we may even show the person? Checks shape, platform, length and that the hash matches the text. */
export async function checkJob(job) {
  if (!job || typeof job !== 'object') return 'Malformed request.';
  const p = PLATFORMS[job.platform];
  if (!p) return 'This site is not supported.';
  if (typeof job.text !== 'string' || !job.text.trim()) return 'The draft is empty.';
  if (job.text.length > p.limit) return `Too long for ${p.label} (${job.text.length}/${p.limit}).`;
  if (typeof job.sha256 !== 'string' || (await sha256Hex(job.text)) !== job.sha256.toLowerCase()) return 'The text does not match what was approved.';
  if (typeof job.draftId !== 'string' || !job.draftId) return 'Missing draft id.';
  return null;
}

export function today(now = new Date()) {
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${now.getFullYear()}-${m}-${d}`;
}

export function capFor(settings, platform) {
  const c = Number(settings?.caps?.[platform]);
  return Number.isInteger(c) && c >= 0 ? Math.min(c, MAX_CAP) : DEFAULT_CAP;
}

export function usedToday(settings, platform, now = new Date()) {
  const rec = settings?.counts?.[platform];
  return rec && rec.day === today(now) ? rec.n : 0;
}

/** Null when a fill may go ahead, else the reason it may not. */
export function blockedReason(settings, platform, now = new Date()) {
  if (settings?.paused?.all) return 'AnalyzeIt is paused in the extension.';
  if (settings?.paused?.[platform]) return `${PLATFORMS[platform].label} is paused in the extension.`;
  const cap = capFor(settings, platform);
  if (usedToday(settings, platform, now) >= cap) return `Daily limit reached for ${PLATFORMS[platform].label} (${cap}). It resets tomorrow.`;
  return null;
}

export function withCount(settings, platform, now = new Date()) {
  const n = usedToday(settings, platform, now) + 1;
  return { ...settings, counts: { ...(settings?.counts || {}), [platform]: { day: today(now), n } } };
}

/** Which page origins may talk to the extension; set by the build. */
export function originAllowed(origin, appOrigins) {
  return appOrigins.includes(origin);
}
