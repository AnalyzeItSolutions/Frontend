// Injected into a platform's compose page, only after the person approved the draft in the app.
// It shows the exact text in its own banner; only a click on "Fill" there puts it in the post box. It never presses Post.
(() => {
  if (window.__analyzeitFiller) return;
  window.__analyzeitFiller = true;

  const norm = (s) => s.replace(/\r\n?/g, '\n').replace(/ /g, ' ').trim();

  function findEditor(selectors, timeoutMs = 15000) {
    return new Promise((resolve) => {
      const started = Date.now();
      const look = () => {
        for (const sel of selectors) {
          const el = document.querySelector(sel);
          if (el) return resolve(el);
        }
        if (Date.now() - started > timeoutMs) return resolve(null);
        setTimeout(look, 250);
      };
      look();
    });
  }

  function setText(el, text) {
    el.focus();
    if (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement) {
      const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, text);
      el.dispatchEvent(new Event('input', { bubbles: true }));
      return norm(el.value) === norm(text);
    }
    const sel = getSelection();
    sel.selectAllChildren(el);
    let ok = false;
    try { ok = document.execCommand('insertText', false, text); } catch (_) {}
    if (!ok || norm(el.innerText) !== norm(text)) {
      const dt = new DataTransfer();
      dt.setData('text/plain', text);
      sel.selectAllChildren(el);
      el.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
    }
    return norm(el.innerText) === norm(text);
  }

  function banner(label, text) {
    return new Promise((resolve) => {
      const host = document.createElement('div');
      host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;left:16px;bottom:16px;max-width:420px';
      const root = host.attachShadow({ mode: 'closed' });
      const style = document.createElement('style');
      style.textContent = `div{font:14px/1.4 system-ui,sans-serif;background:#111;color:#fff;border-radius:12px;padding:14px;box-shadow:0 8px 30px #0006}
        pre{white-space:pre-wrap;word-break:break-word;background:#222;border-radius:8px;padding:8px;max-height:160px;overflow:auto;margin:8px 0;font:inherit}
        button{font:inherit;border:0;border-radius:8px;padding:7px 14px;cursor:pointer;margin-right:8px}
        .go{background:#fff;color:#111}.no{background:#333;color:#fff}`;
      const box = document.createElement('div');
      const head = document.createElement('b');
      head.textContent = 'AnalyzeIt';
      const pre = document.createElement('pre');
      pre.textContent = text;
      const go = document.createElement('button');
      go.className = 'go';
      go.textContent = 'Fill';
      const no = document.createElement('button');
      no.className = 'no';
      no.textContent = 'Cancel';
      box.append(head, ` will put this in your ${label} post box. You press Post yourself.`, pre, go, no);
      root.append(style, box);
      go.addEventListener('click', (e) => { if (e.isTrusted) { host.remove(); resolve(true); } });
      no.addEventListener('click', () => { host.remove(); resolve(false); });
      document.documentElement.append(host);
    });
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type !== 'job') return;
    (async () => {
      const yes = await banner(msg.label, msg.text);
      if (!yes) return chrome.runtime.sendMessage({ type: 'declined', reason: 'You cancelled on the page.' });
      const el = await findEditor(msg.selectors);
      if (!el) return chrome.runtime.sendMessage({ type: 'declined', reason: `Could not find the ${msg.label} post box. The site may have changed; copy the text and paste it by hand.` });
      if (!setText(el, msg.text)) return chrome.runtime.sendMessage({ type: 'declined', reason: 'The text did not land exactly as approved, so it was not accepted. Copy and paste it by hand.' });
      chrome.runtime.sendMessage({ type: 'filled', sha256: msg.sha256 });
    })();
  });
})();
