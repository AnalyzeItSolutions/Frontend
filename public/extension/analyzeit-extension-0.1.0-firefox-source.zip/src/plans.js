// Runs assistant-proposed plans, but only after (1) the app hands over the plan together with the hash of what the person
// approved there, (2) the extension re-validates it against policy.js, and (3) the person clicks Run in the extension's own
// confirmation window. Every step is re-checked against the real page while it runs.
import { PLATFORMS, blockedReason, withCount } from './core.js';
import { validatePlan, planHash, describeStep } from './policy.js';
import { APP_ORIGINS, DEV } from './config.js';

const hostOf = (url) => new URL(url).host;
const originPattern = (host) => `${DEV && host.startsWith('127.0.0.1') ? 'http' : 'https'}://${host}/*`;
const MAX_RUN_MS = 120000;
const AUDIT_MAX = 200;

async function settings() { return (await chrome.storage.local.get('settings')).settings || {}; }
async function saveSettings(s) { await chrome.storage.local.set({ settings: s }); }
async function session(key) { return (await chrome.storage.session.get(key))[key] || {}; }
async function setSession(key, v) { await chrome.storage.session.set({ [key]: v }); }

export async function audit(entry) {
  const { audit: log = [] } = await chrome.storage.local.get('audit');
  log.push({ at: new Date().toISOString(), ...entry });
  await chrome.storage.local.set({ audit: log.slice(-AUDIT_MAX) });
}

function tell(tabId, msg) {
  chrome.tabs.sendMessage(tabId, { source: 'analyzeit-extension', ...msg }).catch(() => {});
}

async function allowedHosts(plan) {
  const hosts = new Set();
  const candidates = new Set();
  for (const s of plan.steps || []) {
    try { if (s.type === 'open') candidates.add(hostOf(s.url)); } catch { /* validatePlan reports it */ }
    if (s.type === 'post' && PLATFORMS[s.platform]) candidates.add(hostOf(PLATFORMS[s.platform].origin));
  }
  for (const h of candidates) if (await chrome.permissions.contains({ origins: [originPattern(h)] })) hosts.add(h);
  return hosts;
}

/** The app handed us a plan. Validate and ask the person in our own window. */
export async function receivePlan(msg, sender) {
  if (!sender.tab || !sender.url || !APP_ORIGINS.includes(new URL(sender.url).origin)) return { ok: false, reason: 'Not from AnalyzeIt.' };
  const plan = msg.plan;
  if (!plan || typeof plan.id !== 'string') return { ok: false, reason: 'Malformed plan.' };
  if ((await planHash(plan)) !== String(msg.sha256 || '').toLowerCase()) return { ok: false, reason: 'The plan does not match what was approved.' };
  const hosts = await allowedHosts(plan);
  const bad = validatePlan(plan, { platforms: PLATFORMS, allowHost: (h) => hosts.has(h), dev: DEV });
  if (bad) return { ok: false, reason: bad };
  const s = await settings();
  for (const st of plan.steps) {
    if (st.type === 'post') {
      const blocked = blockedReason(s, st.platform);
      if (blocked) return { ok: false, reason: blocked };
    }
  }
  if (s.paused?.all) return { ok: false, reason: 'AnalyzeIt is paused in the extension.' };
  const confirms = await session('confirms');
  confirms[plan.id] = { plan: { id: plan.id, title: String(plan.title || '').slice(0, 120), mode: plan.mode, steps: plan.steps }, appTabId: sender.tab.id };
  await setSession('confirms', confirms);
  await chrome.windows.create({ url: chrome.runtime.getURL(`confirm.html?id=${encodeURIComponent(plan.id)}`), type: 'popup', width: 480, height: 640 });
  return { ok: true, state: 'confirming' };
}

const fromExtensionPage = (sender) => !!sender.url && sender.url.startsWith(chrome.runtime.getURL('confirm.html'));

export async function confirmView(msg, sender) {
  if (!fromExtensionPage(sender)) return { ok: false };
  const entry = (await session('confirms'))[msg.id];
  return entry ? { ok: true, plan: entry.plan } : { ok: false };
}

export async function confirmAnswer(msg, sender) {
  if (!fromExtensionPage(sender)) return { ok: false };
  const confirms = await session('confirms');
  const entry = confirms[msg.id];
  if (!entry) return { ok: false };
  delete confirms[msg.id];
  await setSession('confirms', confirms);
  if (!msg.run) {
    tell(entry.appTabId, { type: 'plan-result', planId: msg.id, ok: false, cancelled: true, reason: 'You cancelled in the extension.', results: [] });
    return { ok: true };
  }
  runPlan(entry.plan, entry.appTabId).catch(() => {});
  return { ok: true };
}

function waitComplete(tabId, ms = 20000) {
  return new Promise((resolve) => {
    const t = setTimeout(() => { chrome.tabs.onUpdated.removeListener(fn); resolve(false); }, ms);
    function fn(id, info) { if (id === tabId && info.status === 'complete') { clearTimeout(t); chrome.tabs.onUpdated.removeListener(fn); resolve(true); } }
    chrome.tabs.onUpdated.addListener(fn);
  });
}

async function runner(tabId, step) {
  await chrome.scripting.executeScript({ target: { tabId }, files: ['runner.js'] });
  return chrome.tabs.sendMessage(tabId, { type: 'step', step });
}

async function probePassword(tabId) {
  const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: () => [...document.querySelectorAll('input[type="password"]')].some((e) => e.getClientRects().length > 0) });
  return !!r?.result;
}

async function runPlan(plan, appTabId) {
  const started = Date.now();
  const results = [];
  const allowed = await allowedHosts(plan);
  let tabId = null;
  let fail = null;
  const progress = (index, status) => tell(appTabId, { type: 'plan-progress', planId: plan.id, index, status });

  const go = async (url, host) => {
    if (tabId === null) tabId = (await chrome.tabs.create({ url, active: true })).id;
    else await chrome.tabs.update(tabId, { url });
    await waitComplete(tabId);
    const tab = await chrome.tabs.get(tabId);
    if (!tab.url || hostOf(tab.url) !== host) return `The page moved to ${tab.url ? hostOf(tab.url) : 'another address'} instead of ${host} (for example a sign-in page). Sign in yourself, then run this again.`;
    if (await probePassword(tabId)) return 'The page is asking for a password. The extension never handles passwords: sign in yourself, then run this again.';
    return null;
  };

  for (const [i, step] of plan.steps.entries()) {
    const s = await settings();
    if (s.paused?.all) { fail = 'Stopped: AnalyzeIt was paused in the extension.'; break; }
    if (Date.now() - started > MAX_RUN_MS) { fail = 'Stopped: the plan took too long.'; break; }
    progress(i, 'running');
    let r = { ok: true };
    let host = '';
    try {
      if (step.type === 'open') {
        host = hostOf(step.url);
        const why = await go(step.url, host);
        if (why) r = { ok: false, reason: why };
      } else if (step.type === 'post') {
        const p = PLATFORMS[step.platform];
        host = hostOf(p.origin);
        const blocked = blockedReason(await settings(), step.platform);
        if (blocked) r = { ok: false, reason: blocked };
        else {
          const why = await go(p.compose, host);
          if (why) r = { ok: false, reason: why };
          else {
            r = await runner(tabId, { type: 'post-fill', text: step.text, editor: p.editor, label: p.label });
            if (r.ok) await saveSettings(withCount(await settings(), step.platform));
            if (r.ok && step.commit) r = await runner(tabId, { type: 'post-commit', text: step.text, editor: p.editor, postButton: p.postButton, label: p.label });
          }
        }
      } else {
        if (tabId === null) r = { ok: false, reason: 'Open a page first.' };
        else {
          const tab = await chrome.tabs.get(tabId);
          host = tab.url ? hostOf(tab.url) : '';
          if (!allowed.has(host)) r = { ok: false, reason: `${host || 'That page'} is not a site this plan was approved for.` };
          else r = await runner(tabId, step);
        }
      }
    } catch (e) {
      r = { ok: false, reason: String(e.message || e) };
    }
    results.push({ index: i, ok: !!r.ok, ...(r.text !== undefined ? { text: r.text, untrusted: true } : {}), ...(r.reason ? { reason: r.reason } : {}) });
    await audit({ plan: plan.id, step: step.type, host, ok: !!r.ok, ...(r.reason ? { reason: r.reason.slice(0, 120) } : {}), ...(step.type === 'post' ? { chars: step.text.length, commit: !!step.commit } : {}) });
    if (!r.ok) { fail = r.reason || 'A step failed.'; break; }
    if (step.type === 'wait') await new Promise((res) => setTimeout(res, step.ms));
  }
  tell(appTabId, { type: 'plan-result', planId: plan.id, ok: !fail, reason: fail || undefined, results, steps: plan.steps.map(describeStep) });
}
