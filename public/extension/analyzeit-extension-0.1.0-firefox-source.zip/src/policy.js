// The rules for what an assistant-proposed browser plan may do. Pure functions, no chrome.* calls, mirrored server-side in
// Backend/app/services/browser_plans.py (the shared test vectors in test/vectors.json keep the two in agreement).
//
// A plan is a short list of steps from a closed vocabulary. There is no script execution, no cookie/storage/header access,
// no file upload or download, and no stepping outside the sites the person allowed. The only thing that can press a
// "commit" button (Post) is the built-in `post` step, and only after the person confirms in the extension's own window.

export const STEP_TYPES = ['open', 'read', 'fill', 'click', 'scroll', 'wait', 'post'];
export const MAX_STEPS = 20;
export const MAX_TEXT = 5000;
export const MAX_WAIT_MS = 5000;
export const MAX_READ_CHARS = 8000;

// Buttons and links whose click changes something that is hard to undo. Never clickable through a generic `click` step.
export const RISKY_CLICK = /\b(post|tweet|send|submit|publish|buy|pay|purchase|order|checkout|check out|confirm|delete|remove|unfollow|follow|subscribe|unsubscribe|like|repost|retweet|share|sign ?out|log ?out|transfer|withdraw|accept|agree|place|apply|book|donate|upgrade|cancel (plan|subscription|account)|deactivate|close account)\b/i;

// Fields the extension never types into or reads, whatever the assistant asks.
export const SENSITIVE_FIELD = /\b(pass(word|code)?|pwd|otp|one[- ]?time|2fa|mfa|verification code|security code|card( number)?|cvv|cvc|ssn|social security|iban|routing|account number|secret|token|api[ -]?key|pin)\b/i;
const SENSITIVE_TYPES = new Set(['password']);
const SENSITIVE_AUTOCOMPLETE = /^(cc-|one-time-code|new-password|current-password)/i;

export function isSensitiveField(f = {}) {
  if (SENSITIVE_TYPES.has(String(f.type || '').toLowerCase())) return true;
  if (SENSITIVE_AUTOCOMPLETE.test(String(f.autocomplete || ''))) return true;
  return [f.name, f.id, f.label, f.placeholder, f.ariaLabel].some((v) => v && SENSITIVE_FIELD.test(String(v)));
}

export function isRiskyClickName(name) {
  return RISKY_CLICK.test(String(name || ''));
}

/** JSON with sorted keys and no whitespace. The server computes the same string, so the hashes agree. */
export function canonical(v) {
  if (v === null || typeof v !== 'object') return JSON.stringify(v);
  if (Array.isArray(v)) return '[' + v.map(canonical).join(',') + ']';
  return '{' + Object.keys(v).sort().map((k) => JSON.stringify(k) + ':' + canonical(v[k])).join(',') + '}';
}

export async function planHash(plan) {
  const body = { mode: plan.mode, steps: plan.steps };
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(canonical(body)));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

const isObj = (v) => v && typeof v === 'object' && !Array.isArray(v);

function checkTarget(t) {
  if (!isObj(t)) return 'needs a target';
  const keys = Object.keys(t);
  if (keys.some((k) => !['label', 'name', 'role', 'nth'].includes(k))) return 'target may only use label, name, role, nth';
  if (!t.label && !t.name) return 'target needs a label or name';
  for (const k of ['label', 'name', 'role']) if (t[k] !== undefined && (typeof t[k] !== 'string' || t[k].length > 120)) return `bad target ${k}`;
  if (t.nth !== undefined && !(Number.isInteger(t.nth) && t.nth >= 0 && t.nth < 20)) return 'bad target nth';
  return null;
}

/**
 * Returns null when the plan is acceptable, else a short reason.
 * `ctx.platforms` maps platform id -> { origin, limit }, `ctx.allowHost(host)` says whether the person has allowed that site.
 */
export function validatePlan(plan, ctx) {
  if (!isObj(plan)) return 'Malformed plan.';
  if (!['fill_only', 'fill_and_post'].includes(plan.mode)) return 'Unknown mode.';
  if (!Array.isArray(plan.steps) || plan.steps.length === 0) return 'The plan has no steps.';
  if (plan.steps.length > MAX_STEPS) return `Too many steps (max ${MAX_STEPS}).`;
  let commits = 0;
  for (const [i, s] of plan.steps.entries()) {
    const at = `Step ${i + 1}`;
    if (!isObj(s) || !STEP_TYPES.includes(s.type)) return `${at}: unknown step type.`;
    const extra = Object.keys(s).filter((k) => !['type', 'url', 'what', 'target', 'text', 'direction', 'ms', 'platform', 'commit'].includes(k));
    if (extra.length) return `${at}: unexpected field ${extra[0]}.`;
    if (s.type === 'open') {
      let u;
      try { u = new URL(s.url); } catch { return `${at}: bad address.`; }
      if (u.protocol !== 'https:' && !(ctx.dev && u.protocol === 'http:')) return `${at}: only https addresses are allowed.`;
      if (u.username || u.password) return `${at}: addresses with credentials are not allowed.`;
      if (!ctx.allowHost(u.host)) return `${at}: ${u.host} is not a site you allowed in the extension.`;
    } else if (s.type === 'read') {
      if (!['text', 'links', 'inputs'].includes(s.what)) return `${at}: read must be text, links or inputs.`;
    } else if (s.type === 'fill') {
      const bad = checkTarget(s.target);
      if (bad) return `${at}: ${bad}.`;
      if (typeof s.text !== 'string' || !s.text || s.text.length > MAX_TEXT) return `${at}: text must be 1 to ${MAX_TEXT} characters.`;
      if (isSensitiveField({ label: s.target.label, name: s.target.name })) return `${at}: the extension never fills password, code, card or secret fields.`;
    } else if (s.type === 'click') {
      const bad = checkTarget(s.target);
      if (bad) return `${at}: ${bad}.`;
      if (isRiskyClickName(s.target.name || s.target.label)) return `${at}: clicking "${s.target.name || s.target.label}" is not allowed in a plan. Posting is done with a post step.`;
      if (isSensitiveField({ label: s.target.label, name: s.target.name })) return `${at}: sensitive control.`;
    } else if (s.type === 'scroll') {
      if (!['down', 'up', 'top', 'bottom'].includes(s.direction)) return `${at}: bad scroll direction.`;
    } else if (s.type === 'wait') {
      if (!(Number.isInteger(s.ms) && s.ms >= 0 && s.ms <= MAX_WAIT_MS)) return `${at}: wait must be 0 to ${MAX_WAIT_MS} ms.`;
    } else if (s.type === 'post') {
      const p = ctx.platforms[s.platform];
      if (!p) return `${at}: ${s.platform} is not a supported posting site.`;
      if (typeof s.text !== 'string' || !s.text.trim()) return `${at}: the post is empty.`;
      if (s.text.length > p.limit) return `${at}: too long for ${s.platform} (${s.text.length}/${p.limit}).`;
      if (s.commit) {
        commits += 1;
        if (plan.mode !== 'fill_and_post') return `${at}: pressing Post needs mode fill_and_post.`;
      }
    }
    if (s.type !== 'post' && s.commit) return `${at}: only post steps can commit.`;
  }
  if (commits > 1) return 'A plan can post at most once.';
  return null;
}

/** One line per step, for the confirmation window. The extension renders this itself; it never trusts text from the app. */
export function describeStep(s) {
  switch (s.type) {
    case 'open': return `Open ${s.url}`;
    case 'read': return `Read the page ${s.what === 'text' ? 'text' : s.what === 'links' ? 'links' : 'form field names (no values)'}`;
    case 'fill': return `Type ${s.text.length} characters into "${s.target.label || s.target.name}"`;
    case 'click': return `Click "${s.target.name || s.target.label}"`;
    case 'scroll': return `Scroll ${s.direction}`;
    case 'wait': return `Wait ${s.ms} ms`;
    case 'post': return s.commit ? `Put the post in the ${s.platform} box and press Post` : `Put the post in the ${s.platform} box (you press Post)`;
    default: return s.type;
  }
}

export function redactRead(text) {
  return String(text || '').replace(/\b\d{12,19}\b/g, '[number removed]').slice(0, MAX_READ_CHARS);
}
