import { PLATFORMS, MAX_CAP } from './core.js';

const send = (m) => chrome.runtime.sendMessage(m);
const list = document.getElementById('list');
const all = document.getElementById('all');

async function render(st) {
  st = st || (await send({ type: 'status' }));
  all.checked = st.paused;
  list.replaceChildren();
  for (const [key, p] of Object.entries(st.platforms)) {
    const row = document.createElement('div');
    row.className = 'row';
    const name = document.createElement('b');
    name.textContent = `${p.label} (${p.used}/${p.cap} today)`;
    row.append(name);
    if (!p.allowed) {
      const b = document.createElement('button');
      b.textContent = 'Allow';
      b.onclick = async () => {
        // Must run inside this click: the browser only shows its permission prompt for a user gesture.
        await chrome.permissions.request({ origins: [PLATFORMS[key].origin + '/*'] });
        render();
      };
      row.append(b);
    } else {
      const cap = document.createElement('input');
      cap.type = 'number'; cap.min = 0; cap.max = MAX_CAP; cap.value = p.cap; cap.title = 'Daily limit';
      cap.onchange = async () => render(await send({ type: 'set', platform: key, cap: cap.value }));
      const pause = document.createElement('input');
      pause.type = 'checkbox'; pause.checked = p.paused; pause.title = 'Pause';
      pause.onchange = async () => render(await send({ type: 'set', platform: key, paused: pause.checked }));
      row.append(cap, pause);
      const rev = document.createElement('button');
      rev.textContent = 'Remove';
      rev.onclick = async () => { await chrome.permissions.remove({ origins: [PLATFORMS[key].origin + '/*'] }); render(); };
      row.append(rev);
    }
    list.append(row);
  }
}
all.onchange = async () => render(await send({ type: 'set', paused: all.checked }));
render();

const HOST = /^(?=.{3,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$/i;
document.getElementById('addsite').onclick = async () => {
  const msg = document.getElementById('sitemsg');
  const host = document.getElementById('site').value.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
  if (!HOST.test(host)) { msg.textContent = 'Enter a site name like example.com.'; return; }
  const ok = await chrome.permissions.request({ origins: [`https://${host}/*`] });
  msg.textContent = ok ? `${host} allowed. Remove it any time in the browser's extension settings.` : 'Not allowed.';
};
(async () => {
  const { audit = [] } = await chrome.storage.local.get('audit');
  const ol = document.getElementById('audit');
  for (const a of audit.slice(-20).reverse()) {
    const li = document.createElement('li');
    li.textContent = `${a.at.slice(11, 19)} ${a.step} ${a.host || ''} ${a.ok ? 'ok' : 'refused: ' + (a.reason || '')}`;
    ol.append(li);
  }
})();
