# Rebuilding the Firefox package from source (for addons.mozilla.org review)
Requirements: Node 20+ (tested with 24), npm.

    npm ci
    node scripts/build.mjs --target firefox      # writes dist/firefox
    cd dist/firefox && zip -X -r ../analyzeit-firefox.zip .

`src/*.js` is plain, unminified JavaScript. The only generated file is `dist/firefox/runner.js`, which esbuild bundles from `src/runner.js` and
`src/policy.js` (so it can be injected as a classic script). Everything else is copied unchanged, and `config.js` and `manifest.json` are written by `scripts/build.mjs`.
