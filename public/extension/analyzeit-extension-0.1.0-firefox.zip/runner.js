(() => {
  // dist/firefox/policy.js
  var MAX_READ_CHARS = 8e3;
  var RISKY_CLICK = /\b(post|tweet|send|submit|publish|buy|pay|purchase|order|checkout|check out|confirm|delete|remove|unfollow|follow|subscribe|unsubscribe|like|repost|retweet|share|sign ?out|log ?out|transfer|withdraw|accept|agree|place|apply|book|donate|upgrade|cancel (plan|subscription|account)|deactivate|close account)\b/i;
  var SENSITIVE_FIELD = /\b(pass(word|code)?|pwd|otp|one[- ]?time|2fa|mfa|verification code|security code|card( number)?|cvv|cvc|ssn|social security|iban|routing|account number|secret|token|api[ -]?key|pin)\b/i;
  var SENSITIVE_TYPES = /* @__PURE__ */ new Set(["password"]);
  var SENSITIVE_AUTOCOMPLETE = /^(cc-|one-time-code|new-password|current-password)/i;
  function isSensitiveField(f = {}) {
    if (SENSITIVE_TYPES.has(String(f.type || "").toLowerCase())) return true;
    if (SENSITIVE_AUTOCOMPLETE.test(String(f.autocomplete || ""))) return true;
    return [f.name, f.id, f.label, f.placeholder, f.ariaLabel].some((v) => v && SENSITIVE_FIELD.test(String(v)));
  }
  function isRiskyClickName(name) {
    return RISKY_CLICK.test(String(name || ""));
  }
  function redactRead(text) {
    return String(text || "").replace(/\b\d{12,19}\b/g, "[number removed]").slice(0, MAX_READ_CHARS);
  }

  // dist/firefox/runner.js
  if (!window.__analyzeitRunner) {
    let accessibleName = function(el) {
      const id = el.getAttribute("aria-labelledby");
      const labelled = id ? id.split(/\s+/).map((i) => document.getElementById(i)?.textContent || "").join(" ") : "";
      const forLabel = el.id ? document.querySelector(`label[for="${CSS.escape(el.id)}"]`)?.textContent : "";
      return norm(el.getAttribute("aria-label") || labelled || forLabel || el.closest("label")?.textContent || el.getAttribute("placeholder") || el.getAttribute("title") || el.innerText || el.value || "");
    }, descriptor = function(el) {
      return { type: el.getAttribute("type") || el.tagName.toLowerCase(), name: el.getAttribute("name"), id: el.id, autocomplete: el.getAttribute("autocomplete"), label: accessibleName(el), placeholder: el.getAttribute("placeholder"), ariaLabel: el.getAttribute("aria-label") };
    }, resolve = function(target, kind) {
      const want = lower(target.name || target.label);
      const sel = target.role ? ROLE_SELECTOR[target.role] : kind === "fill" ? ROLE_SELECTOR.textbox : `${ROLE_SELECTOR.button}, ${ROLE_SELECTOR.link}, ${ROLE_SELECTOR.tab}, ${ROLE_SELECTOR.menuitem}`;
      if (!sel) return { error: "Unknown role." };
      const all = [...document.querySelectorAll(sel)].filter(visible);
      const hits = all.filter((el2) => lower(accessibleName(el2)).includes(want));
      if (!hits.length) return { error: `Nothing on the page matches "${target.name || target.label}".` };
      if (hits.length > 1 && target.nth === void 0) return { error: `${hits.length} things match "${target.name || target.label}". Be more specific.` };
      const el = hits[target.nth || 0];
      return el ? { el } : { error: "No match at that position." };
    }, setText = function(el, text) {
      el.focus();
      if (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement) {
        const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        Object.getOwnPropertyDescriptor(proto, "value").set.call(el, text);
        el.dispatchEvent(new Event("input", { bubbles: true }));
        return norm(el.value) === norm(text);
      }
      const sel = getSelection();
      sel.selectAllChildren(el);
      let ok = false;
      try {
        ok = document.execCommand("insertText", false, text);
      } catch (_) {
      }
      if (!ok || norm(el.innerText) !== norm(text)) {
        const dt = new DataTransfer();
        dt.setData("text/plain", text);
        sel.selectAllChildren(el);
        el.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
      }
      return norm(el.innerText) === norm(text);
    }, read = function(what) {
      if (what === "links") {
        return [...document.querySelectorAll("a[href]")].filter(visible).slice(0, 60).map((a) => `${norm(a.innerText).slice(0, 80)} -> ${a.href}`).join("\n");
      }
      if (what === "inputs") {
        return [...document.querySelectorAll('input, textarea, select, [contenteditable="true"]')].filter(visible).slice(0, 60).map((el) => {
          const d = descriptor(el);
          return isSensitiveField(d) ? `(sensitive field: not shown)` : `${d.type}: ${d.label || d.name || d.id || "(unlabelled)"}`;
        }).join("\n");
      }
      const clone = document.body.cloneNode(true);
      clone.querySelectorAll('input, textarea, select, script, style, noscript, [type="password"]').forEach((n) => n.remove());
      return norm(clone.innerText || clone.textContent);
    };
    window.__analyzeitRunner = true;
    const norm = (s) => String(s || "").replace(/\r\n?/g, "\n").replace(/ /g, " ").trim();
    const lower = (s) => norm(s).toLowerCase();
    const visible = (el) => {
      const r = el.getBoundingClientRect();
      const st = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && st.visibility !== "hidden" && st.display !== "none";
    };
    const ROLE_SELECTOR = {
      button: 'button, [role="button"], input[type="button"]',
      link: 'a[href], [role="link"]',
      tab: '[role="tab"]',
      menuitem: '[role="menuitem"]',
      textbox: 'input:not([type]), input[type="text"], input[type="search"], input[type="email"], input[type="url"], textarea, [contenteditable="true"], [role="textbox"]'
    };
    async function waitFor(fn, ms = 15e3) {
      const t = Date.now();
      for (; ; ) {
        const v = fn();
        if (v) return v;
        if (Date.now() - t > ms) return null;
        await new Promise((r) => setTimeout(r, 250));
      }
    }
    const first = (selectors) => {
      for (const s of selectors || []) {
        const el = document.querySelector(s);
        if (el) return el;
      }
      return null;
    };
    chrome.runtime.onMessage.addListener((msg, _sender, respond) => {
      if (msg?.type !== "step") return;
      (async () => {
        const s = msg.step;
        try {
          if (s.type === "read") return respond({ ok: true, text: redactRead(read(s.what)), truncated: read(s.what).length > MAX_READ_CHARS });
          if (s.type === "scroll") {
            const to = { down: () => scrollBy(0, innerHeight * 0.8), up: () => scrollBy(0, -innerHeight * 0.8), top: () => scrollTo(0, 0), bottom: () => scrollTo(0, document.body.scrollHeight) }[s.direction];
            to();
            return respond({ ok: true });
          }
          if (s.type === "fill") {
            const r = resolve(s.target, "fill");
            if (r.error) return respond({ ok: false, reason: r.error });
            if (isSensitiveField(descriptor(r.el))) return respond({ ok: false, reason: "That is a password, code, card or secret field. The extension never fills those." });
            return respond(setText(r.el, s.text) ? { ok: true } : { ok: false, reason: "The text did not land exactly as approved." });
          }
          if (s.type === "click") {
            const r = resolve(s.target, "click");
            if (r.error) return respond({ ok: false, reason: r.error });
            const name = accessibleName(r.el);
            if (isRiskyClickName(name) || isSensitiveField(descriptor(r.el))) return respond({ ok: false, reason: `"${name.slice(0, 60)}" looks like a button that changes something. The extension will not click it.` });
            if (r.el.closest("form")?.querySelector('input[type="password"]')) return respond({ ok: false, reason: "That control is part of a sign-in form." });
            if (r.el instanceof HTMLAnchorElement && r.el.hasAttribute("download")) return respond({ ok: false, reason: "Downloads are not allowed." });
            r.el.click();
            return respond({ ok: true });
          }
          if (s.type === "post-fill") {
            const el = await waitFor(() => first(s.editor));
            if (!el) return respond({ ok: false, reason: `Could not find the ${s.label} post box. The site may have changed; paste the text by hand.` });
            return respond(setText(el, s.text) ? { ok: true } : { ok: false, reason: "The text did not land exactly as approved, so it was not accepted." });
          }
          if (s.type === "post-commit") {
            const el = await waitFor(() => {
              const b = first(s.postButton);
              return b && !b.disabled && b.getAttribute("aria-disabled") !== "true" ? b : null;
            }, 8e3);
            if (!el) return respond({ ok: false, reason: `Could not find an enabled Post button on ${s.label}. Press it yourself.` });
            const box = first(s.editor);
            const now = box ? norm(box.value ?? box.innerText) : "";
            if (now !== norm(s.text)) return respond({ ok: false, reason: "The post box no longer holds the approved text, so Post was not pressed." });
            el.click();
            return respond({ ok: true });
          }
          respond({ ok: false, reason: "Unknown step." });
        } catch (e) {
          respond({ ok: false, reason: String(e.message || e) });
        }
      })();
      return true;
    });
  }
})();
